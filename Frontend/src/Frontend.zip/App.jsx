import { useEffect } from "react";

import {
  Link,
  Navigate,
  Route,
  Routes,
  useLocation,
} from "react-router-dom";

import ShopperLayout from "./layouts/ShopperLayout";

import LoginPage from "./pages/LoginPage";
import SignupPage from "./pages/SignupPage";
import ShopperDashboard from "./pages/ShopperDashboard";
import GuestPage from "./pages/GuestPage";

import CatalogPage from "./pages/CatalogPage";
import ProductDetailsPage from "./pages/ProductDetailsPage";
import SellerStorePage from "./pages/SellerStorePage";

import CartSelectedItems from "./pages/CartSelectedItems";
import ShoppingCartPage from "./pages/ShoppingCartPage";
import CheckoutPage from "./pages/CheckoutPage";

import OrderHistoryPage from "./pages/OrderHistoryPage";
import OrderDetailsPage from "./pages/OrderDetailsPage";

import ChooseAvatarGenderPage from "./pages/ChooseAvatarGenderPage";
import FittingStudioPage from "./pages/FittingStudioPage";
import AvatarPresetPage from "./pages/AvatarPresetPage";
import EditAvatarPresetPage from "./pages/EditAvatarPresetPage";

import SavedOutfitsPage from "./pages/SavedOutfitsPage";
import EditSavedOutfitPage from "./pages/EditSavedOutfitPage";

import AccountManagementPage from "./pages/AccountManagementPage";
import EditAccountPage from "./pages/EditAccountPage";

import "./App.css";

function ScrollToTop() {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo({
      top: 0,
      left: 0,
      behavior: "auto",
    });
  }, [pathname]);

  return null;
}

function TemporaryPage({
  title,
  message,
  returnTo = "/login",
  returnLabel = "Return to Login",
}) {
  return (
    <main className="temporary-page">
      <div>
        <h1>{title}</h1>

        <p>{message}</p>

        <Link to={returnTo}>
          {returnLabel}
        </Link>
      </div>
    </main>
  );
}

function App() {
  return (
    <>
      <ScrollToTop />

      <Routes>
        {/* Default route */}

        <Route
          path="/"
          element={
            <Navigate
              to="/login"
              replace
            />
          }
        />

        {/* Authentication */}

        <Route
          path="/login"
          element={<LoginPage />}
        />

        <Route
          path="/signup"
          element={<SignupPage />}
        />

        <Route
          path="/forgot-password"
          element={
            <TemporaryPage
              title="Forgot Password"
              message="Password recovery will be added next."
              returnTo="/login"
              returnLabel="Return to Login"
            />
          }
        />

        {/* Guest pages */}

        <Route
          path="/guest"
          element={<GuestPage />}
        />

        <Route
          path="/guest/catalog"
          element={
            <TemporaryPage
              title="Guest Catalog"
              message="Guests may browse products, but purchasing requires a registered account."
              returnTo="/guest"
              returnLabel="Return to Guest Dashboard"
            />
          }
        />

        <Route
          path="/guest/fitting-studio"
          element={
            <TemporaryPage
              title="Guest Fitting Studio"
              message="Temporary avatar customization is available during this guest session."
              returnTo="/guest"
              returnLabel="Return to Guest Dashboard"
            />
          }
        />

        <Route
          path="/guest/avatar-presets"
          element={
            <TemporaryPage
              title="Guest Avatar Presets"
              message="One premade avatar is available for temporary use."
              returnTo="/guest"
              returnLabel="Return to Guest Dashboard"
            />
          }
        />

        {/*
          All registered shopper pages are inside
          the same shared ShopperLayout.
        */}

        <Route
          path="/shopper"
          element={<ShopperLayout />}
        >
          {/* Default shopper page */}

          <Route
            index
            element={
              <Navigate
                to="dashboard"
                replace
              />
            }
          />

          {/* Shopper Dashboard */}

          <Route
            path="dashboard"
            element={<ShopperDashboard />}
          />

          {/* Fitting Studio */}

          <Route
            path="fitting-studio"
            element={
              <ChooseAvatarGenderPage />
            }
          />

          <Route
            path="fitting-studio/customize"
            element={<FittingStudioPage />}
          />

          <Route
            path="fitting-studio/select-items"
            element={<CartSelectedItems />}
          />

          {/* Avatar Presets */}

          <Route
            path="avatar-presets"
            element={<AvatarPresetPage />}
          />

          <Route
            path="avatar-presets/:presetId/edit"
            element={
              <EditAvatarPresetPage />
            }
          />

          {/* Catalog */}

          <Route
            path="catalog"
            element={<CatalogPage />}
          />

          <Route
            path="products/:productId"
            element={<ProductDetailsPage />}
          />

          {/* Seller Store */}

          <Route
            path="sellers/:sellerId"
            element={<SellerStorePage />}
          />

          <Route
            path="store/:sellerId"
            element={<SellerStorePage />}
          />

          {/* Saved Outfits */}

          <Route
            path="saved-outfits"
            element={<SavedOutfitsPage />}
          />

          <Route
            path="saved-outfits/:outfitId/edit"
            element={
              <EditSavedOutfitPage />
            }
          />

          {/* Shopping Cart */}

          <Route
            path="cart"
            element={<ShoppingCartPage />}
          />

          {/* Checkout */}

          <Route
            path="checkout"
            element={<CheckoutPage />}
          />

          {/* Order Confirmation */}

          <Route
            path="order-confirmation"
            element={
              <TemporaryPage
                title="Order Confirmed"
                message="Your simulated order was recorded successfully. No real payment was charged."
                returnTo="/shopper/orders"
                returnLabel="View Order History"
              />
            }
          />

          {/* Order History */}

          <Route
            path="orders"
            element={<OrderHistoryPage />}
          />

          {/* Order Details */}

          <Route
            path="orders/:orderId"
            element={<OrderDetailsPage />}
          />

          {/* Account Management */}

          <Route
            path="account"
            element={
              <AccountManagementPage />
            }
          />

          <Route
            path="account/edit"
            element={<EditAccountPage />}
          />
        </Route>

        {/* Seller pages */}

        <Route
          path="/seller/dashboard"
          element={
            <TemporaryPage
              title="Seller Dashboard"
              message="Seller management tools will be added here."
              returnTo="/login"
              returnLabel="Return to Login"
            />
          }
        />

        {/* Unknown URLs */}

        <Route
          path="*"
          element={
            <Navigate
              to="/login"
              replace
            />
          }
        />
      </Routes>
    </>
  );
}

export default App;