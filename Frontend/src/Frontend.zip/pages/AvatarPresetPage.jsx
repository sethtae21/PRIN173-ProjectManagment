import { useEffect, useMemo, useState } from "react";
import { NavLink, useNavigate } from "react-router-dom";

import fitFusionLogo from "../assets/fitfusion-logo.svg";
import "./AvatarPresetPage.css";

const BUILT_IN_PRESET = {
  id: "premade-default",
  name: "FitFusion Standard",
  gender: "Female",
  height: 165,
  weight: 58,
  skinTone: "#d9aa82",
  shoulder: "Balanced",
  waist: "Regular",
  hip: "Balanced",
  thigh: "Regular",
  cupSize: "B",
  builtIn: true,
};

function readStorageArray(key) {
  try {
    const storedValue = JSON.parse(
      localStorage.getItem(key) || "[]"
    );

    return Array.isArray(storedValue)
      ? storedValue
      : [];
  } catch {
    return [];
  }
}

function createPresetId() {
  return `preset-${Date.now()}-${Math.random()
    .toString(16)
    .slice(2)}`;
}

function normalizePreset(preset, index) {
  return {
    id:
      preset.id ||
      preset.presetId ||
      `saved-preset-${index}`,
    name:
      preset.name ||
      preset.presetName ||
      `Custom Avatar ${index + 1}`,
    gender: preset.gender || "Female",
    height: Number(preset.height) || 165,
    weight: Number(preset.weight) || 58,
    skinTone:
      preset.skinTone ||
      preset.skinColor ||
      "#d9aa82",
    shoulder:
      preset.shoulder ||
      preset.shoulderWidth ||
      "Balanced",
    waist:
      preset.waist ||
      preset.waistSize ||
      "Regular",
    hip:
      preset.hip ||
      preset.hipSize ||
      "Balanced",
    thigh:
      preset.thigh ||
      preset.thighSize ||
      "Regular",
    cupSize: preset.cupSize || "B",
    builtIn: Boolean(preset.builtIn),
    createdAt:
      preset.createdAt ||
      new Date().toISOString(),
  };
}

function AvatarPresetPage() {
  const navigate = useNavigate();

  const [customPresets, setCustomPresets] =
    useState([]);
  const [selectedPresetId, setSelectedPresetId] =
    useState(BUILT_IN_PRESET.id);
  const [previewView, setPreviewView] =
    useState("front");
  const [deleteTarget, setDeleteTarget] =
    useState(null);
  const [toastMessage, setToastMessage] =
    useState("");

  useEffect(() => {
    const savedPresets = readStorageArray(
      "fitfusion-avatar-presets"
    ).map(normalizePreset);

    setCustomPresets(savedPresets);
  }, []);

  useEffect(() => {
    if (!toastMessage) {
      return undefined;
    }

    const timer = window.setTimeout(() => {
      setToastMessage("");
    }, 2600);

    return () => window.clearTimeout(timer);
  }, [toastMessage]);

  const allPresets = useMemo(
    () => [BUILT_IN_PRESET, ...customPresets],
    [customPresets]
  );

  const selectedPreset =
    allPresets.find(
      (preset) =>
        preset.id === selectedPresetId
    ) || BUILT_IN_PRESET;

  const cartCount = useMemo(() => {
    return readStorageArray(
      "fitfusion-cart-items"
    ).reduce(
      (total, item) =>
        total + (Number(item.quantity) || 1),
      0
    );
  }, []);

  function saveCustomPresets(nextPresets) {
    setCustomPresets(nextPresets);

    localStorage.setItem(
      "fitfusion-avatar-presets",
      JSON.stringify(nextPresets)
    );
  }

  function selectPreset(preset) {
    setSelectedPresetId(preset.id);
    setPreviewView("front");
  }

  function usePreset(preset) {
    const activePreset = {
      ...preset,
      id: preset.id || createPresetId(),
    };

    localStorage.setItem(
      "fitfusion-avatar-preset",
      JSON.stringify(activePreset)
    );

    localStorage.setItem(
      "fitfusion-avatar-gender",
      activePreset.gender.toLowerCase()
    );

    setToastMessage(
      `${activePreset.name} is now your active avatar.`
    );

    window.setTimeout(() => {
      navigate(
        "/shopper/fitting-studio/customize"
      );
    }, 700);
  }

  function editPreset(preset) {
    if (preset.builtIn) {
      localStorage.setItem(
        "fitfusion-avatar-preset",
        JSON.stringify(preset)
      );

      localStorage.setItem(
        "fitfusion-avatar-gender",
        preset.gender.toLowerCase()
      );

      navigate(
        "/shopper/fitting-studio/customize"
      );

      return;
    }

    localStorage.setItem(
      "fitfusion-editing-avatar-preset",
      JSON.stringify(preset)
    );

    navigate(
      `/shopper/avatar-presets/${preset.id}/edit`
    );
  }

  function requestDelete(preset) {
    if (preset.builtIn) {
      setToastMessage(
        "The built-in preset cannot be deleted."
      );
      return;
    }

    setDeleteTarget(preset);
  }

  function confirmDelete() {
    if (!deleteTarget) {
      return;
    }

    const nextPresets = customPresets.filter(
      (preset) =>
        preset.id !== deleteTarget.id
    );

    saveCustomPresets(nextPresets);

    if (
      selectedPresetId === deleteTarget.id
    ) {
      setSelectedPresetId(
        BUILT_IN_PRESET.id
      );
    }

    const currentPreset = localStorage.getItem(
      "fitfusion-avatar-preset"
    );

    if (currentPreset) {
      try {
        const parsedPreset =
          JSON.parse(currentPreset);

        if (
          parsedPreset.id ===
          deleteTarget.id
        ) {
          localStorage.removeItem(
            "fitfusion-avatar-preset"
          );
        }
      } catch {
        // Keep the page working if stored data is invalid.
      }
    }

    setToastMessage(
      `${deleteTarget.name} was deleted.`
    );
    setDeleteTarget(null);
  }

  function handleLogout() {
    const confirmed = window.confirm(
      "Are you sure you want to log out?"
    );

    if (!confirmed) {
      return;
    }

    sessionStorage.removeItem("userRole");
    sessionStorage.removeItem("userEmail");
    sessionStorage.removeItem(
      "registeredAccount"
    );

    localStorage.removeItem(
      "fitfusion-current-user"
    );

    navigate("/login");
  }

  return (
    <main className="avatar-presets-page">
      <aside className="avatar-presets-sidebar">
        <div className="avatar-presets-logo">
          <img
            src={fitFusionLogo}
            alt="FitFusion AI"
          />
        </div>

        <nav className="avatar-presets-navigation">
          <NavLink
            to="/shopper/dashboard"
            className="avatar-presets-nav-link"
          >
            Dashboard
          </NavLink>

          <NavLink
            to="/shopper/fitting-studio"
            className="avatar-presets-nav-link"
          >
            Fitting Studio
          </NavLink>

          <NavLink
            to="/shopper/avatar-presets"
            className={({ isActive }) =>
              isActive
                ? "avatar-presets-nav-link active"
                : "avatar-presets-nav-link"
            }
          >
            Avatar Presets
          </NavLink>

          <NavLink
            to="/shopper/catalog"
            className="avatar-presets-nav-link"
          >
            Catalog
          </NavLink>

          <NavLink
            to="/shopper/saved-outfits"
            className="avatar-presets-nav-link"
          >
            Saved Outfits
          </NavLink>

          <NavLink
            to="/shopper/orders"
            className="avatar-presets-nav-link"
          >
            Order History
          </NavLink>

          <NavLink
            to="/shopper/account"
            className="avatar-presets-nav-link"
          >
            Account
          </NavLink>
        </nav>

        <button
          type="button"
          className="avatar-presets-logout"
          onClick={handleLogout}
        >
          Logout
        </button>
      </aside>

      <section className="avatar-presets-content">
        <header className="avatar-presets-header">
          <div>
            <p className="avatar-presets-code">
              07 — AVATAR PRESETS
            </p>

            <p className="avatar-presets-description">
              Select, edit, or remove your
              saved 2D avatars
            </p>
          </div>

          <div className="avatar-presets-header-actions">
            <button
              type="button"
              className="avatar-presets-cart"
              onClick={() =>
                navigate("/shopper/cart")
              }
              aria-label={`Open cart with ${cartCount} items`}
            >
              <svg
                viewBox="0 0 24 24"
                aria-hidden="true"
              >
                <path d="M3 4h2l2.1 10.2a2 2 0 0 0 2 1.6h7.9a2 2 0 0 0 1.9-1.4L21 7H6" />
                <circle cx="10" cy="20" r="1" />
                <circle cx="18" cy="20" r="1" />
              </svg>

              <span>{cartCount}</span>
            </button>

            <div className="avatar-presets-role">
              REGISTERED SHOPPER
            </div>
          </div>
        </header>

        <div className="avatar-presets-body">
          <section className="avatar-presets-intro">
            <div>
              <p>YOUR FITTING PROFILE</p>
              <h1>Choose an avatar preset</h1>

              <span>
                Use the premade avatar or select
                one of your saved custom avatars.
              </span>
            </div>

            <button
              type="button"
              className="avatar-presets-create"
              onClick={() =>
                navigate(
                  "/shopper/fitting-studio"
                )
              }
            >
              + Create Custom Avatar
            </button>
          </section>

          <section className="avatar-presets-workspace">
            <div className="avatar-presets-list-panel">
              <div className="avatar-presets-panel-heading">
                <div>
                  <p>AVAILABLE PRESETS</p>
                  <h2>
                    {allPresets.length} avatar
                    {allPresets.length === 1
                      ? ""
                      : "s"}
                  </h2>
                </div>

                <span>
                  {customPresets.length} custom
                </span>
              </div>

              <div className="avatar-presets-grid">
                {allPresets.map((preset) => (
                  <article
                    key={preset.id}
                    className={
                      selectedPresetId ===
                      preset.id
                        ? "avatar-preset-card selected"
                        : "avatar-preset-card"
                    }
                    onClick={() =>
                      selectPreset(preset)
                    }
                  >
                    <button
                      type="button"
                      className="avatar-preset-select-area"
                      onClick={() =>
                        selectPreset(preset)
                      }
                    >
                      <AvatarFigure
                        preset={preset}
                        view="front"
                        small
                      />

                      <span className="avatar-preset-type">
                        {preset.builtIn
                          ? "PREMADE"
                          : "CUSTOM"}
                      </span>

                      <strong>{preset.name}</strong>

                      <small>
                        {preset.gender} •{" "}
                        {preset.height} cm
                      </small>
                    </button>

                    <div className="avatar-preset-card-actions">
                      <button
                        type="button"
                        onClick={(event) => {
                          event.stopPropagation();
                          usePreset(preset);
                        }}
                      >
                        Use
                      </button>

                      <button
                        type="button"
                        onClick={(event) => {
                          event.stopPropagation();
                          editPreset(preset);
                        }}
                      >
                        {preset.builtIn
                          ? "Customize"
                          : "Edit"}
                      </button>

                      {!preset.builtIn && (
                        <button
                          type="button"
                          className="avatar-preset-delete"
                          onClick={(event) => {
                            event.stopPropagation();
                            requestDelete(preset);
                          }}
                        >
                          Delete
                        </button>
                      )}
                    </div>
                  </article>
                ))}
              </div>
            </div>

            <aside className="avatar-preset-preview-panel">
              <div className="avatar-preset-preview-header">
                <div>
                  <p>PREVIEW</p>
                  <h2>{selectedPreset.name}</h2>
                </div>

                <span>
                  {selectedPreset.builtIn
                    ? "Premade"
                    : "Custom"}
                </span>
              </div>

              <div className="avatar-preset-view-buttons">
                {["front", "side", "rear"].map(
                  (view) => (
                    <button
                      key={view}
                      type="button"
                      className={
                        previewView === view
                          ? "active"
                          : ""
                      }
                      onClick={() =>
                        setPreviewView(view)
                      }
                    >
                      {view}
                    </button>
                  )
                )}
              </div>

              <div className="avatar-preset-preview-stage">
                <AvatarFigure
                  preset={selectedPreset}
                  view={previewView}
                />

                <span className="avatar-preset-view-label">
                  {previewView.toUpperCase()} VIEW
                </span>
              </div>

              <div className="avatar-preset-measurements">
                <Measurement
                  label="Gender"
                  value={selectedPreset.gender}
                />

                <Measurement
                  label="Height"
                  value={`${selectedPreset.height} cm`}
                />

                <Measurement
                  label="Weight"
                  value={`${selectedPreset.weight} kg`}
                />

                <Measurement
                  label="Shoulder"
                  value={selectedPreset.shoulder}
                />

                <Measurement
                  label="Waist"
                  value={selectedPreset.waist}
                />

                <Measurement
                  label="Hip"
                  value={selectedPreset.hip}
                />

                <Measurement
                  label="Thigh"
                  value={selectedPreset.thigh}
                />

                {selectedPreset.gender
                  .toLowerCase()
                  .includes("female") && (
                  <Measurement
                    label="Cup size"
                    value={selectedPreset.cupSize}
                  />
                )}
              </div>

              <div className="avatar-preset-preview-actions">
                <button
                  type="button"
                  className="avatar-preset-use-button"
                  onClick={() =>
                    usePreset(selectedPreset)
                  }
                >
                  Use This Avatar
                </button>

                <button
                  type="button"
                  className="avatar-preset-edit-button"
                  onClick={() =>
                    editPreset(selectedPreset)
                  }
                >
                  {selectedPreset.builtIn
                    ? "Customize Avatar"
                    : "Edit Preset"}
                </button>
              </div>
            </aside>
          </section>
        </div>
      </section>

      {deleteTarget && (
        <div
          className="avatar-preset-modal-backdrop"
          role="presentation"
          onMouseDown={() =>
            setDeleteTarget(null)
          }
        >
          <section
            className="avatar-preset-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="delete-preset-title"
            onMouseDown={(event) =>
              event.stopPropagation()
            }
          >
            <div className="avatar-preset-modal-icon">
              !
            </div>

            <p>DELETE AVATAR PRESET</p>

            <h2 id="delete-preset-title">
              Delete “{deleteTarget.name}”?
            </h2>

            <span>
              This avatar preset will be permanently
              removed. Your saved outfits will not be
              deleted.
            </span>

            <div className="avatar-preset-modal-actions">
              <button
                type="button"
                onClick={() =>
                  setDeleteTarget(null)
                }
              >
                Cancel
              </button>

              <button
                type="button"
                className="confirm-delete"
                onClick={confirmDelete}
              >
                Delete Preset
              </button>
            </div>
          </section>
        </div>
      )}

      {toastMessage && (
        <div
          className="avatar-preset-toast"
          role="status"
        >
          {toastMessage}
        </div>
      )}
    </main>
  );
}

function Measurement({ label, value }) {
  return (
    <div className="avatar-preset-measurement">
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}

function AvatarFigure({
  preset,
  view,
  small = false,
}) {
  const genderClass = preset.gender
    .toLowerCase()
    .includes("male")
    ? "male"
    : "female";

  return (
    <div
      className={[
        "preset-avatar",
        `preset-avatar-${genderClass}`,
        `preset-avatar-${view}`,
        small ? "preset-avatar-small" : "",
      ]
        .filter(Boolean)
        .join(" ")}
      style={{
        "--avatar-skin":
          preset.skinTone || "#d9aa82",
      }}
      aria-label={`${preset.name} ${view} view`}
    >
      <div className="preset-avatar-head">
        <span />
      </div>

      <div className="preset-avatar-neck" />

      <div className="preset-avatar-body">
        <div className="preset-avatar-shirt" />
      </div>

      <div className="preset-avatar-arm left" />
      <div className="preset-avatar-arm right" />

      <div className="preset-avatar-leg left" />
      <div className="preset-avatar-leg right" />
    </div>
  );
}

export default AvatarPresetPage;