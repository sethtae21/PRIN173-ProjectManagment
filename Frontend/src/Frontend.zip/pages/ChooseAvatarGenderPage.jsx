import { useMemo, useState } from "react";
import {
  NavLink,
  useNavigate,
} from "react-router-dom";

import fitFusionLogo from "../assets/fitfusion-logo.svg";
import "./ChooseAvatarGenderPage.css";

function getCartCount() {
  try {
    const cartItems = JSON.parse(
      localStorage.getItem(
        "fitfusion-cart-items"
      ) || "[]"
    );

    if (!Array.isArray(cartItems)) {
      return 0;
    }

    return cartItems.reduce(
      (total, item) =>
        total + Number(item.quantity || 1),
      0
    );
  } catch {
    return 0;
  }
}

function getSavedGender() {
  return (
    localStorage.getItem(
      "fitfusion-avatar-gender"
    ) || ""
  );
}

function ChooseAvatarGenderPage() {
  const navigate = useNavigate();

  const [selectedGender, setSelectedGender] =
    useState(getSavedGender);

  const cartCount = useMemo(
    () => getCartCount(),
    []
  );

  function selectGender(gender) {
    setSelectedGender(gender);

    localStorage.setItem(
      "fitfusion-avatar-gender",
      gender
    );
  }

  function continueToCustomization() {
    if (!selectedGender) {
      return;
    }

    navigate(
      "/shopper/fitting-studio/customize",
      {
        state: {
          gender: selectedGender,
        },
      }
    );
  }

  function usePremadeAvatar() {
    navigate("/shopper/avatar-presets");
  }

  function handleLogout() {
    const confirmed = window.confirm(
      "Are you sure you want to log out?"
    );

    if (!confirmed) {
      return;
    }

    sessionStorage.removeItem("userRole");
    sessionStorage.removeItem("userEmail");

    localStorage.removeItem(
      "fitfusion-current-user"
    );

    navigate("/login");
  }

  return (
    <main className="gender-page">
      <aside className="gender-sidebar">
        <NavLink
          className="gender-sidebar-logo"
          to="/shopper/dashboard"
          aria-label="FitFusion dashboard"
        >
          <img
            src={fitFusionLogo}
            alt="FitFusion AI"
          />
        </NavLink>

        <nav
          className="gender-navigation"
          aria-label="Registered shopper navigation"
        >
          <NavLink
            end
            to="/shopper/dashboard"
            className={({ isActive }) =>
              isActive
                ? "gender-nav-link active"
                : "gender-nav-link"
            }
          >
            Dashboard
          </NavLink>

          <NavLink
            to="/shopper/fitting-studio"
            className={({ isActive }) =>
              isActive
                ? "gender-nav-link active"
                : "gender-nav-link"
            }
          >
            Fitting Studio
          </NavLink>

          <NavLink
            to="/shopper/avatar-presets"
            className={({ isActive }) =>
              isActive
                ? "gender-nav-link active"
                : "gender-nav-link"
            }
          >
            Avatar Presets
          </NavLink>

          <NavLink
            to="/shopper/catalog"
            className={({ isActive }) =>
              isActive
                ? "gender-nav-link active"
                : "gender-nav-link"
            }
          >
            Catalog
          </NavLink>

          <NavLink
            to="/shopper/saved-outfits"
            className={({ isActive }) =>
              isActive
                ? "gender-nav-link active"
                : "gender-nav-link"
            }
          >
            Saved Outfits
          </NavLink>

          <NavLink
            to="/shopper/orders"
            className={({ isActive }) =>
              isActive
                ? "gender-nav-link active"
                : "gender-nav-link"
            }
          >
            Order History
          </NavLink>

          <NavLink
            to="/shopper/account"
            className={({ isActive }) =>
              isActive
                ? "gender-nav-link active"
                : "gender-nav-link"
            }
          >
            Account
          </NavLink>
        </nav>

        <button
          className="gender-logout-button"
          type="button"
          onClick={handleLogout}
        >
          Logout
        </button>
      </aside>

      <section className="gender-page-content">
        <header className="gender-header">
          <div>
            <h1>
              09 — CHOOSE AVATAR GENDER
            </h1>

            <p>
              Male or Female body controls
            </p>
          </div>

          <div className="gender-header-actions">
            <button
              className="gender-cart-button"
              type="button"
              onClick={() =>
                navigate("/shopper/cart")
              }
              aria-label={`Open cart with ${cartCount} items`}
            >
              <svg
                viewBox="0 0 24 24"
                aria-hidden="true"
              >
                <path d="M3 4h2l2.1 10.2a2 2 0 0 0 2 1.6h7.9a2 2 0 0 0 1.9-1.4L21 7H6" />

                <circle
                  cx="10"
                  cy="20"
                  r="1"
                />

                <circle
                  cx="18"
                  cy="20"
                  r="1"
                />
              </svg>

              <span>{cartCount}</span>
            </button>

            <div className="gender-role-badge">
              REGISTERED SHOPPER
            </div>
          </div>
        </header>

        <div className="gender-body">
          <section className="gender-introduction">
            <p>AVATAR CREATION</p>

            <h2>Choose avatar gender</h2>

            <span>
              Gender determines which
              body-proportion customization options
              are available.
            </span>
          </section>

          <section
            className="gender-options"
            aria-label="Choose avatar gender"
          >
            <button
              className={
                selectedGender === "Male"
                  ? "gender-option selected"
                  : "gender-option"
              }
              type="button"
              onClick={() =>
                selectGender("Male")
              }
              aria-pressed={
                selectedGender === "Male"
              }
            >
              <div className="gender-avatar-stage">
                <div className="gender-avatar male-avatar">
                  <div className="avatar-hair" />

                  <div className="avatar-head">
                    <span />
                    <span />
                  </div>

                  <div className="avatar-neck" />

                  <div className="avatar-body" />

                  <div className="avatar-left-arm" />

                  <div className="avatar-right-arm" />

                  <div className="avatar-left-leg" />

                  <div className="avatar-right-leg" />
                </div>
              </div>

              <div className="gender-option-information">
                <div>
                  <h3>Male Avatar</h3>

                  <p>
                    Customize shoulders, waist,
                    hips, and thigh proportions.
                  </p>
                </div>

                <span className="gender-selection-indicator">
                  {selectedGender === "Male"
                    ? "✓ Selected"
                    : "Select Male"}
                </span>
              </div>
            </button>

            <button
              className={
                selectedGender === "Female"
                  ? "gender-option selected"
                  : "gender-option"
              }
              type="button"
              onClick={() =>
                selectGender("Female")
              }
              aria-pressed={
                selectedGender === "Female"
              }
            >
              <div className="gender-avatar-stage">
                <div className="gender-avatar female-avatar">
                  <div className="avatar-hair" />

                  <div className="avatar-head">
                    <span />
                    <span />
                  </div>

                  <div className="avatar-neck" />

                  <div className="avatar-body" />

                  <div className="avatar-left-arm" />

                  <div className="avatar-right-arm" />

                  <div className="avatar-left-leg" />

                  <div className="avatar-right-leg" />
                </div>
              </div>

              <div className="gender-option-information">
                <div>
                  <h3>Female Avatar</h3>

                  <p>
                    Includes shoulder, waist,
                    hips, cup size, and thigh
                    controls.
                  </p>
                </div>

                <span className="gender-selection-indicator">
                  {selectedGender === "Female"
                    ? "✓ Selected"
                    : "Select Female"}
                </span>
              </div>
            </button>
          </section>

          {!selectedGender && (
            <p className="gender-selection-message">
              Select Male or Female to continue
              with avatar customization.
            </p>
          )}

          <section className="gender-page-actions">
            <button
              className="gender-premade-button"
              type="button"
              onClick={usePremadeAvatar}
            >
              View Premade Avatar
            </button>

            <button
              className="gender-continue-button"
              type="button"
              disabled={!selectedGender}
              onClick={continueToCustomization}
            >
              Continue to Customization
            </button>
          </section>
        </div>
      </section>
    </main>
  );
}

export default ChooseAvatarGenderPage;